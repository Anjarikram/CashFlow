import {
    useCallback,
    useEffect,
    useState,
} from "react";

import type {
    RecurringTransaction,
} from "../types/recurringTransaction";

import {
    loadRecurringTransactions,
    createRecurringTransaction,
    updateRecurringTransaction,
    deleteRecurringTransaction,
    setRecurringTransactionActive,
    skipNextRecurringOccurrence,
    undoSkipRecurringOccurrence,
    generateDueRecurringTransactions,
} from "../services/recurringTransactionService";

import type {
    CreateRecurringTransactionInput,
    UpdateRecurringTransactionInput,
} from "../services/recurringTransactionService";


export function useRecurringTransactions(
    groupId?: string
) {

    const [
        recurringTransactions,
        setRecurringTransactions,
    ] = useState<RecurringTransaction[]>([]);

    const [
        loading,
        setLoading,
    ] = useState(false);

    const [
        error,
        setError,
    ] = useState<string | null>(null);


    /* =====================================================
       LOAD RECURRING TRANSACTIONS
    ===================================================== */

    const reloadRecurringTransactions =
        useCallback(async () => {

            if (!groupId) {
                setRecurringTransactions([]);
                return;
            }

            try {

                setLoading(true);
                setError(null);

                const result =
                    await loadRecurringTransactions(
                        groupId
                    );

                setRecurringTransactions(result);

            } catch (error) {

                const message =
                    error instanceof Error
                        ? error.message
                        : "Unable to load recurring transactions.";

                setError(message);

            } finally {

                setLoading(false);
            }

        }, [groupId]);


    /* =====================================================
   INITIAL LOAD / GROUP CHANGE
===================================================== */

    useEffect(() => {

        if (!groupId) {
            return;
        }

        const initializeRecurringTransactions =
            async () => {

                try {

                    /*
                     * Generate any recurring transactions
                     * that are currently due.
                     */
                    await generateDueRecurringTransactions(
                        groupId
                    );

                } catch (error) {

                    console.error(
                        "Unable to generate due recurring transactions.",
                        error
                    );

                    /*
                     * Generation failure should not prevent
                     * existing recurring rules from loading.
                     */
                }

                /*
                 * Load the latest recurring rules after
                 * generation has completed.
                 */
                await reloadRecurringTransactions();

            };

        void initializeRecurringTransactions();

    }, [
        groupId,
        reloadRecurringTransactions,
    ]);


    /* =====================================================
       CREATE
    ===================================================== */

    const addRecurringTransaction =
        useCallback(
            async (
                input: CreateRecurringTransactionInput
            ) => {

                setError(null);

                await createRecurringTransaction(
                    input
                );

                await reloadRecurringTransactions();

            },
            [reloadRecurringTransactions]
        );


    /* =====================================================
       UPDATE
    ===================================================== */

    const editRecurringTransaction =
        useCallback(
            async (
                input: UpdateRecurringTransactionInput
            ) => {

                setError(null);

                await updateRecurringTransaction(
                    input
                );

                await reloadRecurringTransactions();

            },
            [reloadRecurringTransactions]
        );


    /* =====================================================
       DELETE
    ===================================================== */

    const removeRecurringTransaction =
        useCallback(
            async (
                recurringTransactionId: string
            ) => {

                setError(null);

                await deleteRecurringTransaction(
                    recurringTransactionId
                );

                await reloadRecurringTransactions();

            },
            [reloadRecurringTransactions]
        );


    /* =====================================================
       PAUSE / RESUME
    ===================================================== */

    const toggleRecurringTransaction =
        useCallback(
            async (
                recurringTransactionId: string,
                isActive: boolean
            ) => {

                setError(null);

                await setRecurringTransactionActive(
                    recurringTransactionId,
                    isActive
                );

                await reloadRecurringTransactions();

            },
            [reloadRecurringTransactions]
        );


    /* =====================================================
       SKIP NEXT
    ===================================================== */

    const skipNextOccurrence =
        useCallback(
            async (
                recurringTransactionId: string,
                nextDueDate: string
            ) => {

                setError(null);

                await skipNextRecurringOccurrence(
                    recurringTransactionId,
                    nextDueDate
                );

                await reloadRecurringTransactions();

            },
            [reloadRecurringTransactions]
        );

    /* =====================================================
       Undo SKIP NEXT
    ===================================================== */

    const undoSkipOccurrence = useCallback(
        async (recurringTransactionId: string) => {
            try {
                setError(null);

                await undoSkipRecurringOccurrence(
                    recurringTransactionId
                );

                await reloadRecurringTransactions();
            } catch (error) {
                console.error(
                    "Unable to undo skipped occurrence.",
                    error
                );

                setError(
                    error instanceof Error
                        ? error.message
                        : "Unable to undo skipped occurrence."
                );
            }
        },
        [reloadRecurringTransactions]
    );
    return {
        recurringTransactions,

        loading,

        error,

        reloadRecurringTransactions,

        addRecurringTransaction,

        editRecurringTransaction,

        removeRecurringTransaction,

        toggleRecurringTransaction,

        skipNextOccurrence,

        undoSkipOccurrence,
    };
}